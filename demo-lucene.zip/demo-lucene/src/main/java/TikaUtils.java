import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.Parser;
import org.apache.tika.sax.BodyContentHandler;

import org.xml.sax.ContentHandler;
import org.xml.sax.SAXException;

public class TikaUtils {

   public static Metadata getFileMetadata(File file) throws IOException, SAXException, TikaException {
      //Parser method parameters
      Parser parser = new AutoDetectParser();
      BodyContentHandler handler = new BodyContentHandler();
      Metadata metadata = new Metadata();
      FileInputStream inputstream = new FileInputStream(file);
      ParseContext context = new ParseContext();

      parser.parse(inputstream, handler, metadata, context);
      System.out.println(handler.toString());

      //getting the list of all meta data elements
      String[] metadataNames = metadata.names();

      for(String name : metadataNames) {
         System.out.println(name + ": " + metadata.get(name));
      }
      return metadata;
   }

   public static Metadata extractMetadatatUsingParser(InputStream stream) throws IOException, SAXException, TikaException {
      Parser parser = new AutoDetectParser();
      ContentHandler handler = new BodyContentHandler();
      Metadata metadata = new Metadata();
      ParseContext context = new ParseContext();

      parser.parse(stream, handler, metadata, context);
      return metadata;
   }

   public static void extractPDFfile(String filePath) throws TikaException, IOException, SAXException {
      PdfParser.extractPDF(filePath);
   }

   public static void main(String[] args) throws TikaException, IOException, SAXException {
      InputStream stream = new FileInputStream(new File("src/main/resources/image/Screen Shot 2021-09-24 at 21.55.47.png"));
      System.out.println(TikaUtils.extractMetadatatUsingParser(stream));


      TikaUtils.extractPDFfile("/Users/vthao95nd/Documents/Thao-workspace/demo-lucene/src/main/resources/Data/record11.pdf");
   }
}