public class Test {
    public static void main(String[] args) throws Exception {
//        String indexDir = "/Users/vthao95nd/Documents/Thao-workspace/demo-lucene/src/main/resources/Index";
//        String dataDir = "/Users/vthao95nd/Documents/Thao-workspace/demo-lucene/src/main/resources/Data";
//        Indexer indexer = new Indexer(indexDir);
//        indexer.createIndex(dataDir);
//        Searcher searcher = new Searcher(indexDir);
//        searcher.searchById("record1");
//        searcher.closeReader();

       // OfficesParse.extractMicrosoftExcel("/Users/vthao95nd/Documents/Thao-workspace/demo-lucene/src/main/resources/Data/record12.docx");
        //OfficesParse.extractMicrosoftExcel("/Users/vthao95nd/Documents/Thao-workspace/demo-lucene/src/main/resources/Data/record13.xlsx");
        ImageParser.extractImage("/Users/vthao95nd/Documents/Thao-workspace/demo-lucene/src/main/resources/image/record15.jpg");
    }
}
