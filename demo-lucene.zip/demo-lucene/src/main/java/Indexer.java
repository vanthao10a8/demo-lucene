import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.StringField;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.IndexWriter;
import org.apache.lucene.index.IndexWriterConfig;
import org.apache.lucene.index.Term;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.FSDirectory;
import org.apache.tika.exception.TikaException;
import org.xml.sax.SAXException;

import java.io.*;
import java.nio.file.Paths;

public class Indexer {
    private String indexDir;
    private IndexWriter w;
    private IndexWriterConfig config;
    private TextFileFilter filter;

    public Indexer(String indexDir) throws IOException {
        StandardAnalyzer analyzer = new StandardAnalyzer();
        Directory index = FSDirectory.open(Paths.get(indexDir));
        config = new IndexWriterConfig(analyzer);
        w = new IndexWriter(index, config);
        filter = new TextFileFilter();
    }

    public void createIndex(String dataDir) throws IOException, TikaException, SAXException {
        File[] files = new File(dataDir).listFiles();
        for (File file : files) {
            if(!file.isDirectory()
                    && !file.isHidden()
                    && file.exists()
                    && file.canRead()
                    && filter.accept(file)
            ){
                System.out.println("Indexing " + file.getCanonicalPath());
                Document document = new Document();
                BufferedReader br = new BufferedReader(new FileReader(file));
                StringBuilder sb = new StringBuilder();
                String line;
                while((line = br.readLine()) != null){
                    sb.append(line);
                }
                document.add(new TextField("title", file.getName(), Field.Store.YES));
                document.add(new TextField("content", sb.toString(), Field.Store.YES));
                document.add(new StringField("uid", file.getName(), Field.Store.YES));
                document.add(new StringField("metadata", TikaUtils.getFileMetadata(file).toString(), Field.Store.YES));

                this.w.updateDocument(new Term("uid", file.getName()), document);
            }
        }
        w.close();
    }
}
